require_relative 'search_index'
require_relative 'review_file'

index = SearchIndex.new
index.build("../reviewUrls.txt", parallel: true)

loop do
  print "Enter a keyword to search: "
  index.query(gets.chomp)
end

