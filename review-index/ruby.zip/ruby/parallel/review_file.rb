require 'set'

class ReviewFile
  attr_reader :title

  def initialize(response_body)
    @reviews = response_body.split("\n")
    @title = @reviews.shift.strip
    @reviews.map! do |review|
      # don't care about the actual text of the review, so split it on spaces
      # and create a Set to eliminate dups
      Set.new(review.strip.split(" ")) - SearchIndex::STOPWORDS
    end
  end

  def index
    @counts ||= @reviews.reduce(Hash.new(0)) do |map, review|
      review.each { |word| map[word] += 1 }
      map
    end
    @counts
  end

end
