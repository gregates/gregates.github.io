package main

import (
  "bufio"
  "fmt"
  "os"
  "io/ioutil"
  "strings"
  "net/http"
)

func main() {
  fmt.Println("Building review index...")

  stopWords := loadStopWords("stopWords.txt")
  index := indexReviews("reviewUrls.txt", stopWords)

  reader := bufio.NewReader(os.Stdin)
  for {
    fmt.Printf("\nEnter a keyword to search: ")
    input, _ := reader.ReadString('\n')
    fmt.Printf("\n")
    if val, ok := index[strings.TrimSpace(input)]; ok {
      for title, count := range val {
        fmt.Println("In", count, "reviews for", title)
      }
    } else {
      fmt.Println("No reviews found.")
    }
  }
}

func indexReviews(filename string, stopWords map[string]bool) map[string]map[string]int {
  file, _ := os.Open(filename)
  defer file.Close()
  index := make(map[string]map[string]int)

  scanner := bufio.NewScanner(bufio.NewReader(file))
  scanner.Split(bufio.ScanLines)
  for scanner.Scan() {
    fmt.Println("indexing", scanner.Text())

    title, localIndex := createLocalIndex(scanner.Text(), stopWords)

    for word, count := range localIndex {
      if _, ok := index[word]; !ok {
        index[word] = make(map[string]int)
      }
      index[word][title] = count
    }
  }
  return index
}

func createLocalIndex(url string, stopWords map[string]bool) (string, map[string]int) {
  res, _ := http.Get(url)
  defer res.Body.Close()
  body, _ := ioutil.ReadAll(res.Body)
  content := strings.Split(string(body), "\n")
  rf := ReviewFile{title: content[0], reviews: content[1:len(content)]}
  text := strings.Join(rf.reviews, "\n")
  localIndex := make(map[string]int)
  words := strings.Split(text, " ")
  for _, word := range words {
    if _, ok := stopWords[word]; ok {
      continue
     }
    count := 0
    for _, review := range rf.reviews {
      if strings.Contains(review, word) {
        count += 1
      }
    }
    localIndex[word] = count
  }
  return rf.title, localIndex
}

func loadStopWords(filename string) map[string]bool {
  file, _ := os.Open(filename)
  defer file.Close()
  set := make(map[string]bool)

  scanner := bufio.NewScanner(bufio.NewReader(file))
  scanner.Split(bufio.ScanLines)
  for scanner.Scan() {
    set[strings.TrimSpace(scanner.Text())] = true
  }
  return set
}

type ReviewFile struct {
  title string
  reviews []string
}
