module ReviewFile
( ReviewFile
, get
, title
, reviews
, wordSet
, reviewCount
) where

import Network.HTTP (simpleHTTP, getResponseBody, getRequest)
import Data.String.Utils (strip)
import qualified Data.Set as S
import qualified Data.Map as M

type ReviewFile = [String]

get :: String -> IO ReviewFile
get url = do
  res  <- simpleHTTP $ getRequest url
  body <- getResponseBody res
  return $ map strip (lines body)

title :: ReviewFile -> String
title (x:_) = x

reviews :: ReviewFile -> [String]
reviews (_:xs) = xs

reviewCounts :: S.Set String -> ReviewFile -> M.Map String Int
reviewCounts words (_:revs) = M.fromList $ S.toList $ S.map (\word -> (word, (reviewCount word revs))) words

reviewCount :: String -> [String] -> Int
reviewCount word xs = foldl (\acc str -> if word `elem` (words str)
                                         then acc + 1
                                         else acc
                            ) 0 xs

wordSet :: [String] -> S.Set String -> S.Set String
wordSet xs stopWords = S.difference (S.unions $ map S.fromList $ map words xs) stopWords
