module ReviewIndex
( ReviewIndex,
  buildSerial,
  fetchReviewsSerial,
  splitFile,
  allWords,
  indexValue
) where

import System.IO
import Data.String.Utils (strip)
import qualified Data.Map.Strict as M
import qualified Data.Set as S
import ReviewFile (get, title, reviews, wordSet, reviewCount, ReviewFile)

type ReviewIndex = M.Map String (S.Set (String, Int))

buildSerial :: String -> String -> IO (M.Map String (S.Set (String, Int)))
buildSerial urls stopWords = do
  reviewFiles <- fetchReviewsSerial $ splitFile urls
  excluded    <- splitFile stopWords
  let words = allWords reviewFiles $ S.fromList excluded
  return $ M.fromSet (\word -> S.fromList (indexValue word reviewFiles)) words

indexValue :: String -> [ReviewFile] -> [(String, Int)]
indexValue word files = [ (title file, reviewCount word file) | file <- files, reviewCount word file > 0 ]

fetchReviewsSerial :: IO [String] -> IO [ReviewFile]
fetchReviewsSerial urlFile = do
  urls <- urlFile
  mapM (\url -> do
                putStrLn $ "indexing " ++ url
                get url
       ) urls

splitFile :: String -> IO [String]
splitFile filename = do
  reviewUrls <- readFile filename
  return $ map strip $ lines reviewUrls

allWords :: [ReviewFile] -> S.Set String -> S.Set String
allWords files stopWords = S.unions $ map (\file -> wordSet (reviews file) stopWords) files
