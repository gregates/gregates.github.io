import System.Environment
import ReviewIndex (buildSerial, ReviewIndex)
import qualified Data.Map as M
import qualified Data.Set as S

main :: IO ()
main = do
       reviewIndex  <- buildSerial "testUrls.txt" "stopWords.txt"
       putStrLn "Finished."
       putStrLn "Enter a keyword to search: "
       interact $ unlines . search reviewIndex . lines

search :: ReviewIndex -> ([String] -> [String])
search index = map $ formatResults . (query index)

query :: ReviewIndex -> String -> Maybe (S.Set (String, Int))
query index keyword = M.lookup keyword index

formatResults :: Maybe (S.Set (String, Int)) -> String
formatResults Nothing  = "No reviews found."
formatResults (Just s) = unlines $ S.toList $ S.map (\(title, count) -> "In " ++ show count ++ " reviews for " ++ title) s
