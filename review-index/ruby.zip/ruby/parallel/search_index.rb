require 'pathname'
require 'faraday'
require 'typhoeus'

class SearchIndex

  STOPWORDS = Set.new(File.readlines(Pathname.new("../stopWords.txt")).map(&:strip))

  def initialize
    @index = {}
  end

  def query(word)
    return puts "No results found" if @index[word].nil? || @index[word].empty?
    # doing a naive array sort here to get the results in "relevance" order does
    # not scale, but is adequate given that the size of the "counts" for each
    # word will not get that large unless we have an astronomical dataset
    @index[word].to_a.sort!{ |x, y| y[1] <=> x[1] }.each do |result|
      puts "In #{result[1]} review#{result[1] > 1 ? "s" : ""} for #{result[0]}"
    end
  end

  def build(path_to_file, opts={})
    start_time = Time.now
    puts "Starting index at #{start_time}"
    path = Pathname.new(path_to_file)
    file = File.open(path)
    if opts[:parallel]
      build_parallel(file)
    else
      build_serial(file)
    end
    file.close
    end_time = Time.now
    puts "Finished at #{end_time}"
    puts "Elapsed time: #{end_time - start_time}s"
  end

  def build_parallel(file)
    hydra = Typhoeus::Hydra.new

    while url = file.gets do
      request = Typhoeus::Request.new(url.chomp)
      request.on_complete do |res|
        puts "indexing #{res.request.base_url}"
        review_file = ReviewFile.new(res.body)
        add_to_index(review_file)
      end
      hydra.queue(request)
    end

    hydra.run
  end

  def build_serial(file)
    conn = Faraday.new

    while url = file.gets do
      puts "indexing #{url}"
      res = conn.get url.chomp
      review_file = ReviewFile.new(res.body)
      add_to_index(review_file)
    end
  end

  def add_to_index(review_file)
    review_file.index.each do |word, count|
      @index[word] ||= {}
      @index[word][review_file.title] ||= 0
      @index[word][review_file.title] += count
    end
  end

end
